import { filter, makeMovieCards } from "./fetch_movie_list.js";
// 영화 목록 불러오기 기능
document.addEventListener("DOMContentLoaded", makeMovieCards());

document.getElementById("search").addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    if (!event.target.value) {
      document.querySelectorAll(".card").forEach((card) => {
        card.style.display = "flex";
      });
      alert("검색어를 입력해주세요.");
    } else {
      filter();
    }
  }
});

document.querySelector("#searchBtn").addEventListener("click", (event) => {
  console.log(event.currentTarget);
  if (!event.target.parentNode.querySelector("#search").value) {
    document.querySelectorAll(".card").forEach((card) => {
      card.style.display = "flex";
    });
    alert("검색어를 입력해주세요.");
    event.preventDefault();
  } else {
    filter();
  }
});

console.log(localStorage.getItem("a"));

//좋아요 버튼
const heartSvg = document.querySelector(".feed-icon.like-default");
const heartPath = document.querySelector(".feed-icon.like-default path");

heartSvg.addEventListener("click", () => changeClass(heartSvg, heartPath));
function fillHeartRed(heartSvg, heartPath) {
  if (heartSvg.classList.contains("like-default")) {
    heartSvg.classList.remove("like-default");
    heartSvg.classList.add("like-fill");
    heartPath.setAttribute("d", "M34.6 3....");
  } else {
    heartSvg.classList.remove("like-fill");
    heartSvg.classList.add("like-default");
    heartPath.setAttribute("d", "M34.6 6....");
  }
}
